-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-10-2024 a las 18:16:22
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bltn_dgtl`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

CREATE TABLE `alumnos` (
  `IdAlumn` int(6) NOT NULL COMMENT 'Id del alumno',
  `Año` int(1) NOT NULL COMMENT 'Año del alumno',
  `Curso` int(1) NOT NULL COMMENT 'Curso del alumno',
  `DNI` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Número DNI',
  `Contraseña` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Contraseña del usuario',
  `Usuario` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Username del usuario',
  `Email` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Email del usuario',
  `Apellido` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Apellido del alumno',
  `Nombre` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Nombre del alumno'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grado`
--

CREATE TABLE `grado` (
  `IdAlumn` int(6) NOT NULL,
  `IdProf` int(6) NOT NULL,
  `IdCurso` int(6) NOT NULL,
  `Año` int(1) NOT NULL,
  `Curso` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materia`
--

CREATE TABLE `materia` (
  `IdMateria` int(6) NOT NULL COMMENT 'Id de las Materias',
  `IdNota` int(10) NOT NULL COMMENT 'Id de las Notas',
  `NomMat` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Nombre de las materias'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Tabla de las Notas';

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nota`
--

CREATE TABLE `nota` (
  `IdAlumn` int(6) NOT NULL COMMENT 'Id de los Alumnos',
  `IdCurso` int(6) NOT NULL COMMENT 'Id de del curso',
  `IdNotas` int(6) NOT NULL COMMENT 'Id de las notas',
  `NomMat` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Nombre de las materias'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor`
--

CREATE TABLE `profesor` (
  `IdProf` int(6) NOT NULL COMMENT 'Id del Profesor',
  `Año` int(1) NOT NULL COMMENT 'Año del Profesor',
  `Curso` int(1) NOT NULL COMMENT 'Año del Curso',
  `IdMateria` int(6) NOT NULL COMMENT 'Id de la Materia',
  `Contraseña` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Contraseña del usuario',
  `Usuario` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Username del USuario',
  `Email` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Email del usuario',
  `Apellido` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Apellido del profesor',
  `Nombre` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Nombre del profesor',
  `DNI` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'DNI del profesor'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `UserName` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Nombre de Usuario',
  `Contraseña` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Contraseña de Usuario'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  ADD PRIMARY KEY (`Curso`,`Año`,`IdAlumn`);

--
-- Indices de la tabla `grado`
--
ALTER TABLE `grado`
  ADD PRIMARY KEY (`IdAlumn`,`IdProf`,`IdCurso`,`Año`,`Curso`);

--
-- Indices de la tabla `materia`
--
ALTER TABLE `materia`
  ADD PRIMARY KEY (`IdMateria`,`IdNota`);

--
-- Indices de la tabla `nota`
--
ALTER TABLE `nota`
  ADD PRIMARY KEY (`IdAlumn`,`IdCurso`,`IdNotas`);

--
-- Indices de la tabla `profesor`
--
ALTER TABLE `profesor`
  ADD PRIMARY KEY (`IdMateria`,`Curso`,`Año`,`IdProf`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
